#ifndef __LIBRARY_INNER_H__
#define __LIBRARY_INNER_H__

void WrappedLib_CommonInit(library_t* lib);
void WrappedLib_FinishFini(library_t* lib);

#endif