#ifndef __ARM64_IMMENC_H__
#define __ARM64_IMMENC_H__

#include <stdint.h>

int convert_bitmask(uint64_t bitmask);

#endif // __ARM64_IMMENC_H__
