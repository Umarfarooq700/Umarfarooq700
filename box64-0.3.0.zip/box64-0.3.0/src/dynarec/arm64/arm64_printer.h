#ifndef _ARM_PRINTER_H_
#define _ARM_PRINTER_H_

const char* arm64_print(uint32_t opcode, uint64_t addr);

#endif //_ARM_PRINTER_H_
