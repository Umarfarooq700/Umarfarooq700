#ifndef _LA64_PRINTER_H_
#define _LA64_PRINTER_H_

const char* la64_print(uint32_t opcode, uint64_t addr);

#endif //_LA64_PRINTER_H_
