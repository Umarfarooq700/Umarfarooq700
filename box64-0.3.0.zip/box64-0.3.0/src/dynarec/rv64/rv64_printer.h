#ifndef _RV64_PRINTER_H_
#define _RV64_PRINTER_H_
#include <stdint.h>
#include<stdbool.h>

const char* rv64_print(uint32_t data, uint64_t addr);

#endif //_RV64_PRINTER_H_
