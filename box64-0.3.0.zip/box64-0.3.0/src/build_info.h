#ifndef __BUILD_INFO_H__
#define __BUILD_INFO_H__

void PrintBox64Version(void);

#endif //__BUILD_INFO_H__